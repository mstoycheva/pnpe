package task_3;

public class OverstockException extends RuntimeException {
    public OverstockException(String message) {
        super(message);
    }
}
