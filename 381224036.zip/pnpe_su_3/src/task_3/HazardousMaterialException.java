package task_3;

public class HazardousMaterialException extends RuntimeException {
    public HazardousMaterialException(String message) {
        super(message);
    }
}
