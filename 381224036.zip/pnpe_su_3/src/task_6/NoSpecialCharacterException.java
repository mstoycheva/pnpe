package task_6;

public class NoSpecialCharacterException extends RuntimeException {
    public NoSpecialCharacterException(String message) {
        super(message);
    }
}
