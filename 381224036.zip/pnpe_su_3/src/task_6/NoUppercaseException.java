package task_6;

public class NoUppercaseException extends RuntimeException {
  public NoUppercaseException(String message) {
    super(message);
  }
}
