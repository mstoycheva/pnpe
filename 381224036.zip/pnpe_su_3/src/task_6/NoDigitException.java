package task_6;

public class NoDigitException extends RuntimeException {
    public NoDigitException(String message) {
        super(message);
    }
}
